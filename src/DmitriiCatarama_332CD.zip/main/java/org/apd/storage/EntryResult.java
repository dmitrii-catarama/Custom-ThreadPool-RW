package org.apd.storage;

/* DO NOT MODIFY */
public record EntryResult(int index, String data, int sequence) {
}
