package org.apd.executor;

/* DO NOT MODIFY */
public enum LockType {
    ReaderPreferred,
    WriterPreferred1,
    WriterPreferred2,
}
